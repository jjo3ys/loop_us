import pandas as pd
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status

from .models import School, Department

@api_view(['POST'])
def set_school(request):
    # bulk_list = []
    # list_obj = pd.read_excel("school_email.xlsx", index_col=None, header=None).to_numpy().tolist()
    # for email in list_obj:
    #     if '폴리텍' in email[0] and 'ICT' not in email[0]:
    #         school = '한국폴리텍대학'+email[0].split()[-1]
    #     else:
    #         school = email[0]
    #     bulk_list.append(School(school=school, email=email[1]))
    # School.objects.bulk_create(bulk_list)
    school_obj = School.objects.all()
    list_obj = pd.read_csv('department.csv', index_col=None, encoding='cp949').to_numpy().tolist()
    bulk_list = []
    for d in list_obj:
        school = d[0]
        if '사이버' in school:
            continue
        if '폴리텍' in school and 'ICT' not in school:
            school = '한국폴리텍대학'+school.split()[-1]
        if '(' in school:
            school = school.split('(')[0]
        if d[1] != '본교':
            school += ' ' + d[1]
        
        bulk_list.append(Department(school=school_obj.filter(school=school)[0], department=d[2]))
            # print(len(bulk_list))
    Department.objects.bulk_create(bulk_list)
    return Response(status=status.HTTP_200_OK)